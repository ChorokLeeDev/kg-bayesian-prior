UAI 2026 Submission - Anonymous for Review
===========================================

Title: Decomposing Uncertainty in Probabilistic Knowledge Graph Embeddings:
       Why Entity Variance Is Not Enough

FINAL VERSION - Clean Figure 1 (No Text Overlaps)

Files:
------
main_uai.tex               - LaTeX source (anonymous)
main_uai_anonymous.pdf     - Compiled PDF (18 pages)
uai2024.cls                - UAI style file
references.bib             - Bibliography
sections/*.tex             - Paper sections
figures/fig1_main_results.pdf - Main results figure (CLEAN)

Compile:
--------
pdflatex main_uai.tex
bibtex main_uai
pdflatex main_uai.tex
pdflatex main_uai.tex

Results (FB15k-237 Temporal OOD):
----------------------------------
Baselines:     0.52-0.61 AUROC (near-random)
Semantic:      0.542 AUROC
Structural:    0.935 AUROC
Simple avg:    0.951 AUROC
CAGP (ours):   0.986 AUROC ⭐

Improvements: 60-80% relative over baselines

Submission: UAI 2026, Amsterdam (Aug 17-21, 2026)
Deadline: February 25, 2026 (23:59 AoE)
