UAI 2026 Submission Package (Anonymous for Review)
===================================================

Title: Decomposing Uncertainty in Probabilistic Knowledge Graph Embeddings:
       Why Entity Variance Is Not Enough

Author: Anonymous (for double-blind review)

Main Files:
-----------
- main_uai.tex                 : Main LaTeX source (ANONYMOUS)
- main_uai_anonymous.pdf       : Compiled PDF (18 pages, anonymous)
- uai2024.cls                  : UAI 2024 style file
- references.bib               : Bibliography

Sections:
---------
sections/abstract_uai.tex      : Abstract
sections/introduction_uai.tex  : Introduction
sections/related_work_uai.tex  : Related Work
sections/background.tex        : Background
sections/method_uai_v2.tex     : Method (CAGP)
sections/experiments_uai.tex   : Experiments
sections/conclusion_uai.tex    : Conclusion

Figures:
--------
figures/fig1_main_results.pdf  : Main results (updated, no text overlaps)

Compilation:
------------
To compile from source:
  pdflatex main_uai.tex
  bibtex main_uai
  pdflatex main_uai.tex
  pdflatex main_uai.tex

Requirements:
-------------
- Standard LaTeX distribution (TeX Live, MiKTeX, etc.)
- No special packages required beyond standard UAI style

Key Contributions:
------------------
1. Impossibility theorem: Relation-agnostic uncertainty fails on novel contexts
2. Complementarity theorem: Semantic + structural signals are non-redundant
3. CAGP method: Coverage-Augmented GP-KGE for temporal OOD detection
4. 100% empirical validation of theoretical assumptions (3 datasets)
5. 0.94-0.99 AUROC on temporal OOD (60-80% improvement over baselines)

Results Summary (FB15k-237):
----------------------------
- Probabilistic baselines: 0.52-0.64 AUROC (near-random)
- Semantic signal only: 0.542 AUROC
- Structural signal only: 0.935 AUROC
- Simple average (α=0.5): 0.951 AUROC
- CAGP (learned α): 0.986 AUROC

Submission Deadline: February 25, 2026 (23:59 AoE)
Conference: UAI 2026, Amsterdam, August 17-21, 2026

Contact:
--------
See author information after acceptance
