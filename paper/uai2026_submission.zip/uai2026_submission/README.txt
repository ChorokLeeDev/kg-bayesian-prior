UAI 2026 Submission Package
============================

Title: Uncertainty Decomposition in Knowledge Graph Embeddings:
       Detecting Emerging Entities vs Novel Relational Contexts

Main Files:
-----------
- main_uai.tex         : Main LaTeX source file
- main_uai.pdf         : Compiled PDF (18 pages)
- uai2024.cls          : UAI 2024 style file
- references.bib       : Bibliography

Sections:
---------
sections/abstract_uai.tex      : Abstract
sections/introduction_uai.tex  : Introduction
sections/related_work_uai.tex  : Related Work
sections/background.tex        : Background
sections/method_uai_v2.tex     : Method (CAGP)
sections/experiments_uai.tex   : Experiments
sections/conclusion_uai.tex    : Conclusion

Figures:
--------
figures/fig1_main_results.pdf  : Main results figure

Compilation:
------------
To compile from source:
  pdflatex main_uai.tex
  bibtex main_uai
  pdflatex main_uai.tex
  pdflatex main_uai.tex

Requirements:
-------------
- Standard LaTeX distribution (TeX Live, MiKTeX, etc.)
- No special packages required beyond standard UAI style

Key Contributions:
------------------
1. Impossibility theorem: Relation-agnostic uncertainty fails on novel contexts
2. Complementarity theorem: Semantic + structural signals are non-redundant
3. CAGP method: Coverage-Augmented GP-KGE for temporal OOD detection
4. 100% empirical validation of theoretical assumptions (3 datasets)
5. 0.94-0.99 AUROC on temporal OOD (60-80% improvement over baselines)

Contact:
--------
See main_uai.tex for author information (anonymized for review)
